create database optimizer;

create user 'optimizer'@'%' IDENTIFIED BY 'entice';

grant all privileges on optimizer.* TO 'optimizer'@'%';

flush privileges;

