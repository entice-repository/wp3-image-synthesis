create database virtualimages;

create user 'entice'@'%' IDENTIFIED BY 'entice';
grant all privileges on virtualimages.* TO 'entice'@'%';
flush privileges;

