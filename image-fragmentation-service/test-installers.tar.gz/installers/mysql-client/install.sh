#!/bin/bash
apt-get -y install mysql-client