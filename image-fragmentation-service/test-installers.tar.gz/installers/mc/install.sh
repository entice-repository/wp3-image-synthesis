#!/bin/bash
apt-get -q -y install mc
