#!/bin/bash
apt-get update
apt-get -y install mysql-client
