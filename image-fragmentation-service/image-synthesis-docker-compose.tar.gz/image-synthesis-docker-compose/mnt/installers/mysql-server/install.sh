#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
apt-get -q -y install debconf-utils mysql-server
service mysql stop