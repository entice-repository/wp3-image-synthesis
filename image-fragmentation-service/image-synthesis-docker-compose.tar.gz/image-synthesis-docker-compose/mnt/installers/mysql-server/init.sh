#!/bin/bash
service mysql-server start