#!/bin/bash
apt-get -y install tomcat