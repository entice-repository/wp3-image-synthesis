create database IF NOT EXISTS virtualimages;
create database IF NOT EXISTS optimizer;
create user IF NOT EXISTS 'entice'@'%' IDENTIFIED BY 'entice';
grant all privileges on virtualimages.* TO 'entice'@'%';
grant all privileges on optimizer.* TO 'entice'@'%';
flush privileges;

