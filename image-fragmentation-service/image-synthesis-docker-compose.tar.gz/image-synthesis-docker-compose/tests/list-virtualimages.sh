#!/bin/bash
curl -X GET -H "Accept: application/json" http://localhost:8080/virtual-image-manager/rest/virtualimages
