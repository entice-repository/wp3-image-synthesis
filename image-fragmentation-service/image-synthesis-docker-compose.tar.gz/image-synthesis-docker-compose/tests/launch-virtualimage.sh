#!/bin/bash
if [ $# < 3 ]; then 
  echo Usage: $0 <virtual image id> <access key> <secret key>
  exit 1
fi
JSON='{virtualImageId:"'$1'",keypair:ahajnal_keypair,cloud:sztaki,endpoint:"http://cfe2.lpds.sztaki.hu:4567",accessKey:"'$2'",secretKey:"'$3'",instanceType:m1.medium}'
curl -X POST -v -H "Content-Type: application/json" -d $JSON http://localhost:8080/virtual-image-launcher/rest/launcher
